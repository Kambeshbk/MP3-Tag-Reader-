#include "header_file.h"
#include <stdio.h>
#include <string.h>
#include<unistd.h>

int main(int argc, char* argv[])
{
    char filename[256];
    if ( (argc == 2 && strcmp(argv[1], "-h")==0)||(argc == 1)){
       print();
       return 0;
    }

    if (argc == 3 && strcmp(argv[1], "-v") == 0) {
        FILE *fptr = fopen(argv[2], "r");
        if (!fptr) {
            printf("\033[1;31mError: Cannot open %s\033[0m\n", argv[2]);
            return 1;
        }
        if (read_tags(fptr) == 0)
            printf("\033[1;32mTags displayed successfully\033[0m\n");
        else
            printf("\033[1;31mFailed to read tags\033[0m\n");
        fclose(fptr);
        return 0;
    }

    if (argc == 4) {
        char *file = argv[1];
        char *option = argv[2];
        char *new_data = argv[3];

        FILE *src = fopen("temp.mp3", "w");
        FILE *des = fopen(file, "r");
        if (!src || !des) {
            printf("\033[1;31mError opening files\033[0m\n");
            return 1;
        }

        int status = 1;
        if (strcmp(option, "-t") == 0)
            status = copy_remain(src, des, new_data, "TIT2");
        else if (strcmp(option, "-A") == 0)
            status = copy_remain(src, des, new_data, "TPE1");
        else if (strcmp(option, "-a") == 0)
            status = copy_remain(src, des, new_data, "TALB");
        else if (strcmp(option, "-y") == 0)
            status = copy_remain(src, des, new_data, "TYER");
        else if (strcmp(option, "-c") == 0)
            status = copy_remain(src, des, new_data, "COMM");
        else if (strcmp(option, "-C") == 0)
            status = copy_remain(src, des, new_data, "TCON");
        else {
            print();
            fclose(src);
            fclose(des);
            return 1;
        }

        fclose(src);
        fclose(des);

        remove(file);
        rename("temp.mp3", file);

        if (status == 0)
            printf("\033[1;32mTag updated successfully\033[0m\n");
        else
            printf("\033[1;31mFailed to update tag\033[0m\n");

        return 0;
    }
    print();
    return 1;
}

